export type AddUserTable = {
  userId: number;
  name: string;
  email: string;
  position: string;
};
