export interface IFormValues {
  roleId: number;
  roleName: string;
  roleDescription: string;
}
