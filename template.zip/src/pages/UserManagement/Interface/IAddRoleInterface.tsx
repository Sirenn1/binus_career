export interface IFormValues {
  roleName: string;
  roleDescription: string;
}
