export type ListRoleTable = {
  roleId: string;
  roleName: string;
  roleDescription: string;
  totalUsers: string;
  totalPermission: string;
};
