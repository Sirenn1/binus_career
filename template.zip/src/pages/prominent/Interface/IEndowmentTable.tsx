export interface IEndowmentTable {
    endowmentId : number;
    period : Date;
    activity : string;
    kredit : number;
    debit : number;
}