export interface IEngagementTable {
    engagementId : number;
    period : Date;
    activity : string;
    nominal : number;
}