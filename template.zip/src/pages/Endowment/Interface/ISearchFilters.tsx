export type SearchFilters = {
    campusId: string[];
    facultyId: string[];
    programId: string[];
    degreeId: string[];
    endowmentCategoryId: string[];
    startDate: string;
    endDate: string;
}