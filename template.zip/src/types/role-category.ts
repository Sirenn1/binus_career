export type RoleCategories = {
    id: string;
    name: string;
  };
  
  export type RoleCategoryProps = RoleCategories[];
  