import { SxProps, Theme } from '@mui/material/styles';

export type SxStyle = SxProps<Theme>;
