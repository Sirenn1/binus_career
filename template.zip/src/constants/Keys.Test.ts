const Keys = {
    googleVision: '',
    vapid: '',
    firebase: '',
    // ClientID: '84771f27-f933-4f43-baa0-2e803a124abc',
    ClientID: 'c81dea07-5789-4018-8a9d-ed4a9a5a62c0',
    TenantID: '3485b963-82ba-4a6f-810f-b5cc226ff898',
    DivisionID: '2FC09145-C3F8-4377-A0DF-F285B00AD4FB'
};

export default Keys;
