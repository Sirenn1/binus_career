/* eslint-disable import/no-named-as-default */
/* eslint-disable unicorn/prefer-export-from */
import Keys from './Keys.Dev';

export default Keys;
