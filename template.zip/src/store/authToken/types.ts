export type AuthTokenState = {
    myDashboardToken: string;
    azureADToken: string;
    refreshToken: string;
  };
  