export interface PaginationControls {
  pageIndex: number;
  pageCount: number;
  setPageIndex: (page : number) => void;
}